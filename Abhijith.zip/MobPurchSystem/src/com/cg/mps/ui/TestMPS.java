package com.cg.mps.ui;
import com.cg.mps.dto.*;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.PurchaseException;
import com.cg.mps.service.PurchaseService;
import com.cg.mps.service.PurhcaseServiceImpl;

import java.util.ArrayList;
import java.util.Scanner;
public class TestMPS {
	
	static PurchaseService purService=null;

	public static void main(String[] args) throws PurchaseException {
		// TODO Auto-generated method stub
		
		System.out.println("******Welcome to Mobile Purchase System*****");
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("What do you want to do?");
			System.out.println(" 1:Insert Customer \n "
					+ "2:Display Mobiles available\n "
					+ "3:Delete Mobiles based on MOBID\n"+"4:Search Mobiles based on range\n"
					+ " 5:Exit");
			System.out.println("Enter ur choice");
			int choice=0;
			purService=new PurhcaseServiceImpl();
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertDetails(); break;
			case 2:showDetails();break;
			case 3:deleteMobiles();break;
			case 4:searchMobiles();break;
			case 6:System.exit(0);
default:System.out.println("Invalid input");

			
			}
		}

	}
		
	private static void searchMobiles() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ArrayList<Mobile> mobList;
		try {
			System.out.println("Enter the min range");
			int min=sc.nextInt();
			System.out.println("Enter the max range");
			int max=sc.nextInt();
			mobList=purService.searchMob(min, max);
	
		System.out.println("\tMID  \t MOBNAME \tPRICE \tQUANTITY");
		for(Mobile mm:mobList)
		{
			System.out.println("\t"+mm.getmId()+"\t"+mm.getMname()+"\t"+mm.getMprice()+"\t"+mm.getMqty());
		}
		} catch (PurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

	private static void deleteMobiles() throws PurchaseException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Mobile ID you want to delete");
		int mID=sc.nextInt();
		purService.deleteMob(mID);
		
		
		
	}

	private static void insertDetails() throws PurchaseException {
		// TODO Auto-generated method stub

	
		Scanner sc=new Scanner(System.in);
		/*System.out.println("Enter the Custumer ID");
		int cID=sc.nextInt();*/
		System.out.println("Enter Custumer Name");
		String cName=sc.next();
		if(purService.validateCustomername(cName))
		{ 
			System.out.println("Enter Custumer Mail ID");
			String cMID=sc.next();
			if(purService.validateMailid(cMID)){
			System.out.println("Enter Custumer Phone Number");
			String cNumber=sc.next();
			if(purService.validateCphonenumber(cNumber)){
			/*String date2=purService.validateDate();*/
			System.out.println("Enter mobile id");
			int mid=sc.nextInt();
			Customer c1=new Customer(0,cNumber,cName,cMID,mid);
			int dataInserted=purService.addCust(c1);
			System.out.println();
			if(dataInserted==1)
			{
				purService.updateMob(c1.getMid());
				showCustDetails();
				showDetails();
				
			}
			else
			{ 

				System.out.println("Sorry data is not inserted");
			}
		}}}
		}
		
	
	private static void showCustDetails() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ArrayList<Customer> custList=null;;
		try {
			custList = purService.getAllCust();
		System.out.println("\tPURCHASEID  \t NAME \tMAILID \tPHONE \tPDATE");
		for(Customer cc:custList)
		{
			System.out.println("\t"+cc.getcPid()+"\t"+cc.getCname()+"\t"+cc.getCmail()+"\t"+cc.getCphone()+"\t"+cc.getCpDate()+"\t"+cc.getMid());
		}
		} catch (PurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private static void showDetails() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ArrayList<Mobile> mobList;
		try {
			mobList = purService.getAllMobile();
		System.out.println("\tMID  \t MOBNAME \tPRICE \tQUANTITY");
		for(Mobile mm:mobList)
		{
			System.out.println("\t"+mm.getmId()+"\t"+mm.getMname()+"\t"+mm.getMprice()+"\t"+mm.getMqty());
		}
		} catch (PurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}


