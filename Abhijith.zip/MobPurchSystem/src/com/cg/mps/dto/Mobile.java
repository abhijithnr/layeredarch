package com.cg.mps.dto;

public class Mobile {
	private int mId;
	private String mname;
	private float mprice;
	private String mqty;
	public Mobile() {
	}
	public Mobile(int mId, String mname, float mprice, String mqty) {
		super();
		this.mId = mId;
		this.mname = mname;
		this.mprice = mprice;
		this.mqty = mqty;
	}
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public float getMprice() {
		return mprice;
	}
	public void setMprice(float mprice) {
		this.mprice = mprice;
	}
	public String getMqty() {
		return mqty;
	}
	public void setMqty(String mqty) {
		this.mqty = mqty;
	}
	@Override
	public String toString() {
		return "Mobile [mId=" + mId + ", mname=" + mname + ", mprice=" + mprice
				+ ", mqty=" + mqty + "]";
	}
	
	

}
