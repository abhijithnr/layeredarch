package com.cg.mps.dto;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.sql.*;
public class Customer {
	private String cname;
	private String cmail;
	private String cphone;
	private  int cPid;
	private Date cpDate;
	private int mid;
	
	public Customer(int cPid,String cname, String cmail, String cphone,
			int mid) {
		super();
		this.cname = cname;
		this.cmail = cmail;
		this.cphone = cphone;
		this.cPid = cPid;
		java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
		 this.cpDate = date;
		this.mid = mid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCmail() {
		return cmail;
	}
	public void setCmail(String cmail) {
		this.cmail = cmail;
	}
	public String getCphone() {
		return cphone;
	}
	public void setCphone(String cphone) {
		this.cphone = cphone;
	}
	public int getcPid() {
		return cPid;
	}
	public void setcPid(int cPid) {
		this.cPid = cPid;
	}
	public Date getCpDate() {
		return cpDate;
	}
	
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	@Override
	public String toString() {
		return "Customer [cname=" + cname + ", cmail=" + cmail + ", cphone="
				+ cphone + ", cPid=" + cPid + ", cpDate=" + cpDate + ", mid="
				+ mid + "]";
	}
	
	
	
	
	

}
