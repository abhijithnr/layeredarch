package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.exception.PurchaseException;
import com.cg.mps.util.DBUtil;
import com.cg.mps.dto.Customer;
import com.cg.mps.exception.PurchaseException;
import com.cg.mps.util.*;
import com.cg.mps.dao.*;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.PurchaseException;


public class CustDaoImpl implements CustDao {
	Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	ArrayList<Customer> custList=null;
	public CustDaoImpl()
	{
		daoLogger=Logger.getLogger(CustDaoImpl.class);
		PropertyConfigurator.configure("D:/Abhijith/MobPurchSystem/dbInfo.properties");
	}

	@Override
	public ArrayList<Customer> getAllCust() throws PurchaseException {
		// TODO Auto-generated method stub

		ArrayList<Customer> custList=new ArrayList<Customer>();
		try
		{
			
			con=DBUtil.getConn();
			String selectqry="SELECT * FROM PURCHASEDETAILS";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				custList.add(new Customer(rs.getInt(1),rs.getString("cname"),rs.getString("mailid"),rs.getString("phoneno"),rs.getInt("mobileid")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PurchaseException(e.getMessage());
		}
		finally
		{
		try {
			st.close();
			rs.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			daoLogger.error(e.getMessage());
			e.printStackTrace();
		}
		}
		daoLogger.info("All data received:"+custList);
		return custList;
	}

	@Override
	public int addCust(Customer cs) throws PurchaseException {
		// TODO Auto-generated method stub
		int data;
		try {
			con=DBUtil.getConn();
			String insertQry="INSERT INTO PURCHASEDETAILS(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) VALUES(sequence2.nextval,?,?,?,?,?)";
			pst=con.prepareStatement(insertQry);
			/*pst.setInt(1, cs.getcPid());*/
			pst.setString(1, cs.getCname());
			pst.setString(2, cs.getCmail());
			pst.setString(3, cs.getCphone());
			pst.setDate(4,(Date) cs.getCpDate());
			pst.setInt(5,cs.getMid());
			data=pst.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new PurchaseException(e.getMessage());
		} 
		
		return data;
	}


	@Override
	public ArrayList<Mobile> searchMob(int minPrice,int maxPrice) throws PurchaseException {
		// TODO Auto-generated method stub
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		try
		{
			
			con=DBUtil.getConn();
			String selectqry="SELECT * FROM MOBILES WHERE PRICE>? AND PRICE<?";
			pst=con.prepareStatement(selectqry);
			pst.setInt(1,minPrice);
			pst.setInt(2, maxPrice);
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getString("quantity")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PurchaseException(e.getMessage());
		}
		finally
		{
		try {
			pst.close();
			rs.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			daoLogger.error(e.getMessage());
			e.printStackTrace();
		}
		}
		daoLogger.info("All data received:"+mobList);
	
		return mobList;
	}

	@Override
	public int updateMob(int mid) throws PurchaseException {
		// TODO Auto-generated method stub
		int data=0;
		try {
			con=DBUtil.getConn();
			int quantity=0;
			String query="select * from mobiles where mobileid=?";
			pst=con.prepareStatement(query);
			pst.setInt(1,mid);
			rs=pst.executeQuery();
			if(rs.next())
				 quantity=rs.getInt("quantity");
			System.out.println(quantity);
			quantity--;
			
			rs=null;
			if(quantity>0){
				String updateQry="update mobiles set quantity=? where mobileid=?";
				pst=con.prepareStatement(updateQry);
				pst.setString(1,quantity+"");
				pst.setInt(2, mid);
			 data=pst.executeUpdate();
			}
			 System.out.println("data updated in table");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new PurchaseException(e.getMessage());
		} 
		
		
		return data;
	}

	@Override
	public int deleteMob(int mid) throws PurchaseException {
		// TODO Auto-generated method stub
		int data=0;
		int data1=0;
		try {
			con=DBUtil.getConn();
			String deletequery="delete from mobiles where mobileid=?";
			String deletequery1="delete from purchasedetails where mobileid=?";
			pst=con.prepareStatement(deletequery1);
			pst.setInt(1,mid);
			data1=pst.executeUpdate();
			System.out.println("Data deleted from purchase table");
			pst=con.prepareStatement(deletequery);
			 pst.setInt(1, mid);
			 data=pst.executeUpdate();
			 System.out.println("data deleted in mobile table");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new PurchaseException(e.getMessage());
		} 
		
		return data;
	}

	@Override
	public ArrayList<Mobile> getAllMobile() throws PurchaseException {
		
		ArrayList<Mobile> mobList1=new ArrayList<Mobile>();
		try
		{
			
			con=DBUtil.getConn();
			String selectqry="SELECT * FROm MOBILES";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				mobList1.add(new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getString("quantity")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PurchaseException(e.getMessage());
		}
		finally
		{
		try {
			st.close();
			rs.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			daoLogger.error(e.getMessage());
			e.printStackTrace();
		}
		}
		daoLogger.info("All data received:"+custList);
		return mobList1;
	}

}
