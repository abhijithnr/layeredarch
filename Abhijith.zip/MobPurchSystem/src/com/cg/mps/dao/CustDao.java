package com.cg.mps.dao;
import java.util.ArrayList;

import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.PurchaseException;
import com.cg.mps.dto.Customer;
import com.cg.mps.exception.PurchaseException;

public interface CustDao {
	public ArrayList<Customer>getAllCust() throws PurchaseException;
	public ArrayList<Mobile>getAllMobile() throws PurchaseException;
	public ArrayList<Mobile>searchMob(int minPrice ,int maxPrice) throws PurchaseException;
	public int addCust(Customer cs) throws PurchaseException;
	public int updateMob(int mid)throws PurchaseException;
	public int deleteMob(int mid)throws PurchaseException;
	
	

}
