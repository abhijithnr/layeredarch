package com.cg.ems.ui;
import com.cg.ems.dto.Employee;


import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

import java.util.ArrayList;
import java.util.Scanner;

public class TestEmpMGSClient {
	static EmpService empService=null;

	public static void main(String[] args) throws EmployeeException {
		// TODO Auto-generated method stub
		System.out.println("******Welcome to EMS*****");
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("What do you want to do?");
			System.out.println("\t 1:Add Emp \t "
					+ "2:Show all Emp \n\t "
					+ "3:Update Emp \t "
					+ "4:Delete Emp \t\n"
					+ "\t 5:Exit");
			System.out.println("Enter ur choice");
			int choice=0;
			empService=new EmpServiceImpl();
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertDetails(); break;
			case 2:showDetails();break;
			case 3:updateDetails();break;
			case 4:deleteEmployee();break;
			case 5:System.exit(0);
default:System.out.println("Invalid input");

			
			}
		}

	}

	private static void showDetails() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ArrayList<Employee> empList;
		try {
			empList = empService.getAllEmp();
		System.out.println("\t EmpID \t EMPNAME \tEMPSAL");
		for(Employee ee:empList)
		{
			System.out.println("\t"+ee.getEmpId()+"\t"+ee.getEmpName()+"\t"+ee.getEmpSal());
		}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void insertDetails() throws EmployeeException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id");
		int eId=sc.nextInt();
		System.out.println("Enter name");
		String enm=sc.next();
		float esl=0.0F;
		if(empService.validateEmpname(enm))
		{
			System.out.println("Enter salary");
			esl=sc.nextFloat();
			Employee e1=new Employee(eId,enm,esl);
			int dataInserted=empService.addEmp(e1);
			if(dataInserted==1)
			{
				showDetails();
			}
			else
			{
				System.out.println("Sorry data is not inserted");
			}
		}
		
		
	}

	private static void updateDetails() {
		// TODO Auto-generated method stub
		
	}

	private static void deleteEmployee() {
		// TODO Auto-generated method stub
		
	}

}
