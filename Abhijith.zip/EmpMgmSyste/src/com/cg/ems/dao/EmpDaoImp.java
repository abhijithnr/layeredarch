package com.cg.ems.dao;

import java.util.ArrayList;
import java.io.IOException;
import java.sql.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmpDaoImp implements EmpDao {
	
	Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	ArrayList<Employee> empList=null;
	public EmpDaoImp()
	{
		daoLogger=Logger.getLogger(EmpDaoImp.class);
		PropertyConfigurator.configure("D:/Abhijith/EmpMgmSyste/Resources/log4j.properties");
	}
	@Override
	public ArrayList<Employee>getAllEmp() throws EmployeeException
	{
		ArrayList<Employee> empList=new ArrayList<Employee>();
		try
		{
			
			con=DBUtil.getConn();
			String selectqry="SELECT * FROM emp_158009";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				empList.add(new Employee(rs.getInt("emp_id"),rs.getString("emp_name"),rs.getFloat("emp_salary")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
		try {
			st.close();
			rs.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			daoLogger.error(e.getMessage());
			e.printStackTrace();
		}
		}
		daoLogger.info("All data received:"+empList);
		return empList;
	}
	@Override
	public int addEmp(Employee ee) throws EmployeeException
	
	{
		int data;
		try {
			con=DBUtil.getConn();
			String insertQry="INSERT INTO EMP_158009 VALUES(?,?,?)";
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, ee.getEmpId());
			pst.setString(2, ee.getEmpName());
			pst.setFloat(3, ee.getEmpSal());
			data=pst.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		} 
		
		return data;
	}

}
